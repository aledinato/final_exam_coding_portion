// Copyright (c) 2025 Ethan Sifferman.
// All rights reserved. Distribution Prohibited.

#pragma once

void createRandomImage(const char* filename, int width, int height);
